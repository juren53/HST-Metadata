#!/usr/bin/env python3
#__description__ = "A graphical menu system for HST metadata utilities"
#__filename__ = "HST-metadata-yyyy-mm-dd.py"
#__author__ = "Jim U'Ren"
#__credits__ = "Jim U'Ren"
#__license__ = "GPL"
#__version__ = ".03"
#__developer__ = "Jim U'Ren"
#__email__ = "jim.uren@gmail.com"
#__status__ = "alpha"
#__updated__ = Thu 11 Feb 2020 01:37:11 PM CST
#
#########################


from tkinter import *          # GUI libraries
from tkinter import filedialog # GUI libraries
import tkinter as tk           # GUI libraries
import os                      # provides access to OS commands
import glob                    # provides access to OS commands
import subprocess as sub       # provides access to OS commands

from PIL import *


def donothing():
   filewin = Toplevel(root)
   button = Button(filewin, text="This is a place holder")
   button.pack()

def list_JPG_files():
   win = tk.Tk()
   win.title("JPG Files")
   win.geometry("150x400+50+150") # Width x Height + Location (X/Y)
   dir = folder_path.get()
   os.chdir(dir)   
 
   flist = glob.glob('*.jpg')
 
   lbox = tk.Listbox(win)
   #lbox.geometry(("100x400") # Width x Height + Location (X/Y)
   lbox.pack()

   for item in flist:
       print(item)
       lbox.insert(tk.END, item)

   win.mainloop()

def listfiles():
   win = tk.Tk()
   win.title("TIF Files")
   win.geometry("300x400+70+150") # Width x Height + Location (X/Y)
   dir = folder_path.get()
   os.chdir(dir)   
 
   flist = glob.glob('*.tif')
 
   lbox = tk.Listbox(win)
   lbox.pack()

   for item in flist:
       print(item)
       lbox.insert(tk.END, item)

   win.mainloop()

def list_tags():

    root = tk.Tk()
    root.title("IPTC Tags")
    root.geometry("600x400+300+100") # Width x Height + Location (X/Y)
    dir = folder_path.get()
    os.chdir(dir)

    os.system("exiftool -iptc:all *.tif > x")
   
    file = open("x")
    data = file.read()
    file.close()

    text = Text(root)
    text.pack()

    text.insert(END, data)
    root.wm_attributes("-topmost", 1) # sets top most window

    root.mainloop()

def browse_button():
    # User selects a directory and stores it as global var
    # called folder_path
    global folder_path
    global dir
    filename = filedialog.askdirectory()
    folder_path.set(filename)

def exitapp():
    root.destroy()
    root.quit()
	
	
# Main "Dashboard" Window
	
root = Tk()

icon = PhotoImage(file="ICON_HST.gif")
root.tk.call('wm', 'iconphoto', root._w, icon)

root.title("HST AV Archives Metadata Project")

root.geometry("900x600+10+10") # Width x Height + Location (X/Y)

text = Label(root, text="Alpha Ver 0.3   2020-02-13", font=("Helvetica", 10))
text.place(x=730,y=575)

# Prints current working directory

lbl1 = Label(master=root, text = "Current Working Directory:", font=("Helvetica", 12))
lbl1.grid(row=0, column=0, sticky = W)

folder_path = StringVar()
filename = os.getcwd()
folder_path.set(filename)
lbl2 = Label(master=root,textvariable=folder_path, font=("Helvetica", 12))
lbl2.grid(row=2, column=0, sticky = W)

# Buttons on dashboard

button2 = Button(text="Change Working Directory", padx=45,command=browse_button)
button2.grid(row=4, column=0, sticky = W)
button3 = Button(text="List JPG files in Directory",padx=45, pady=10, command=list_JPG_files)
button3.grid(row=6, column=0, sticky = W)
button4 = Button(text="List TIF files in Directory",padx=45, pady=10, command=listfiles)
button4.grid(row=8, column=0, sticky = W)
button5 = Button(text="List Metadata Tags in TIF Files",padx=45, pady=10, command=list_tags)
button5.grid(row=10, column=0, sticky = W)
button5a = Button(text="Covert JPGs to TIFFs",padx=45, pady=10,fg="red", command=donothing)
button5a.grid(row=14, column=0, sticky = W)
button7 = Button(text="Write Object Tag(s) from File Name(s)", padx=30, pady=10,  fg="red", command=donothing)
button7.grid(row=16, column=0, sticky = W)
button8 = Button(text="Write Location and Collection Tag(s)", padx=30, pady=10,  fg="red", command=donothing)
button8.grid(row=18, column=0, sticky = W)


button6 = Button(text="Pull metadata from HST-PDB", padx=30, pady=10, command=donothing)
button6.grid(row=4, column=1, sticky = W)


#Drop down menus

menubar = Menu(root)
filemenu = Menu(menubar, tearoff = 0)

menubar.add_cascade(label = "File", menu = filemenu)
filemenu.add_command(label = "Set Working Directory", command = listfiles)
filemenu.add_command(label = "List JPG Files", command = list_JPG_files)
filemenu.add_command(label = "List TIF Files", command = listfiles)
filemenu.add_command(label = "List Tags in Files", command = list_tags)
filemenu.add_command(label = "List Tags from HST PDB", command = donothing)
filemenu.add_command(label = "Write Tags from HST PDB", command = donothing)
filemenu.add_command(label = "Write Photographer, Collection and Editor  Tags", command = donothing)
filemenu.add_command(label = "Save as...", command = donothing)
filemenu.add_command(label = "Close", command = donothing)

filemenu.add_separator()

filemenu.add_command(label = "Exit", command = exitapp)

editmenu = Menu(menubar, tearoff=0)

menubar.add_cascade(label = "Edit", menu = editmenu)
#editmenu.add_command(label = "Undo", command = donothing)

#editmenu.add_separator()

editmenu.add_command(label = "Edit Tags for a photo", command = donothing)
#editmenu.add_command(label = "Copy", command = donothing)
#editmenu.add_command(label = "Paste", command = donothing)
#editmenu.add_command(label = "Delete", command = donothing)
#editmenu.add_command(label = "Select All", command = donothing)


viewmenu = Menu(menubar, tearoff=0)
menubar.add_cascade(label = "View", menu = viewmenu)
viewmenu.add_command(label = "List JPG Files", command = list_JPG_files)
viewmenu.add_command(label = "List TIF Files", command = listfiles)
viewmenu.add_command(label = "List Tags in TIF Files", command = list_tags)
viewmenu.add_command(label = "List Tags from HST PDB", command = donothing)



helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label = "Help Index", command = donothing)
helpmenu.add_command(label = "About...", command = donothing)
menubar.add_cascade(label = "Help", menu = helpmenu)


# display the menu
root.config(menu = menubar)

root.mainloop()
