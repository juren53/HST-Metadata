# exif-list-all.py

from tkinter import filedialog
from tkinter import *

import os

root = Tk()
root.withdraw()
folder_selected = filedialog.askdirectory()

print(str(folder_selected))


os.system("clear")

os.system("exiftool -iptc:all " + folder_selected + "/*.tif | less")

