# !/usr/bin/python3
# menu.py
#Thu 05 Dec 2019 07:37:11 AM CST 

from tkinter import *          # GUI libraries
from tkinter import filedialog # GUI libraries
import tkinter as tk           # GUI libraries
import os                      # provides access to OS commands
import glob                    # provides access to OS commands
import subprocess as sub       # provides access to OS commands


def donothing():
   filewin = Toplevel(root)
   button = Button(filewin, text="Place holder button")
   button.pack()

def list_JPG_files():
   win = tk.Tk()
   win.title("JPG Files")
   win.geometry("150x400+50+150") # Width x Height + Location (X/Y)
   dir = folder_path.get()
   os.chdir(dir)   
 
   flist = glob.glob('*.jpg')
 
   lbox = tk.Listbox(win)
   #lbox.geometry(("100x400") # Width x Height + Location (X/Y)
   lbox.pack()

   for item in flist:
       print(item)
       lbox.insert(tk.END, item)

   win.mainloop()

def listfiles():
   win = tk.Tk()
   win.title("TIF Files")
   win.geometry("300x400+70+150") # Width x Height + Location (X/Y)
   dir = folder_path.get()
   os.chdir(dir)   
 
   flist = glob.glob('*.tif')
 
   lbox = tk.Listbox(win)
   lbox.pack()

   for item in flist:
       print(item)
       lbox.insert(tk.END, item)

   win.mainloop()

def list_tags():

    root = tk.Tk()
    root.title("IPTC Tags")
    root.geometry("600x400+300+100") # Width x Height + Location (X/Y)
    dir = folder_path.get()
    os.chdir(dir)

    os.system("exiftool -iptc:all *.tif > x")
   
    file = open("x")
    data = file.read()
    file.close()

    text = Text(root)
    text.pack()

    text.insert(END, data)
    root.wm_attributes("-topmost", 1) # sets top most window

    root.mainloop()

def browse_button():
    # User selects a directory and stores it as global var
    # called folder_path
    global folder_path
    global dir
    filename = filedialog.askdirectory()
    folder_path.set(filename)

def exitapp():
    root.quit()

root = Tk()

root.title("HST AV Archives Metadata Tool")

root.geometry("900x600+10+10") # Width x Height + Location (X/Y)

folder_path = StringVar()
lbl1 = Label(master=root,textvariable=folder_path)
lbl1.grid(row=0, column=0)
button2 = Button(text="Select Working Directory", command=browse_button)
button2.grid(row=4, column=0)


menubar = Menu(root)
filemenu = Menu(menubar, tearoff = 0)

menubar.add_cascade(label = "File", menu = filemenu)
filemenu.add_command(label = "Set Working Directory", command = listfiles)
filemenu.add_command(label = "List JPG Files", command = list_JPG_files)
filemenu.add_command(label = "List TIF Files", command = listfiles)
filemenu.add_command(label = "List Tags in Files", command = list_tags)
filemenu.add_command(label = "List Tags from HST PDB", command = donothing)
filemenu.add_command(label = "Write Tags from HST PDB", command = donothing)
filemenu.add_command(label = "Write Photographer, Collection and Editor  Tags", command = donothing)
filemenu.add_command(label = "Save as...", command = donothing)
filemenu.add_command(label = "Close", command = donothing)

filemenu.add_separator()

filemenu.add_command(label = "Exit", command = exitapp)

editmenu = Menu(menubar, tearoff=0)

menubar.add_cascade(label = "Edit", menu = editmenu)
editmenu.add_command(label = "Undo", command = donothing)

editmenu.add_separator()

editmenu.add_command(label = "Cut", command = donothing)
editmenu.add_command(label = "Copy", command = donothing)
editmenu.add_command(label = "Paste", command = donothing)
editmenu.add_command(label = "Delete", command = donothing)
editmenu.add_command(label = "Select All", command = donothing)


viewmenu = Menu(menubar, tearoff=0)
menubar.add_cascade(label = "View", menu = viewmenu)
viewmenu.add_command(label = "All Files", command = donothing)
viewmenu.add_command(label = "Single File", command = donothing)

helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label = "Help Index", command = donothing)
helpmenu.add_command(label = "About...", command = donothing)
menubar.add_cascade(label = "Help", menu = helpmenu)


# display the menu
root.config(menu = menubar)

root.mainloop()
