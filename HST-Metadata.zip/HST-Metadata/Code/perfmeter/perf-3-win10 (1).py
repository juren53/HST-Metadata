#!/usr/bin/env python3
#__description__ = "A graphical performance meter"
#__filename__ = "perf-3.py"
#__author__ = "Jim U'Ren"
#__copyright__ = "Copyright 2019, SynchroSoft"
#__credits__ = ["Jim U'Ren"]
#__license__ = "GPL"
#__version__ = ".02"
#__maintainer__ = "Jim U'Ren"
#__email__ = "jim.uren@gmail.com"
#__status__ = "pre-alpha"
#########################

import tkinter
from tkinter import *
import tkinter as tk
#from tkinter.font import Font
#from tkinter import messagebox
import time
#import random
import gaugelib
import psutil
import os

tr = .7      # sets transparency level 1 - opaque 0 - clear
tm = 1       # sets top most window setting level 1 - always on top 0 - like all other windows

global pos
pos = "0"     # sets position of window 0 = left 1000 = right

g_size = 175      # sets size 
g_color = "grey"  # sets background color

win = tk.Tk()
a5 = PhotoImage(file="g1.png")
win.tk.call('wm', 'iconphoto', win._w, a5)
win.title("Perf Meter")
win.geometry("175x500+"+pos+"+0")
win.resizable(width=True, height=True)
win.configure(bg=g_color)

text = Label(win, text="2019-12-27", bg='Grey', fg='White', font=("Helvetica", 7))
text.place(x=120,y=485)

x=0

############# Pop-up Menu #############################

def showMenu(e):
    pmenu.post(e.x_root, e.y_root)

def changePosRight():
    global pos
    pos = "1000"
    #print(pos)
    win.geometry("175x500+"+pos+"+0")

def changePosLeft():
    global pos
    pos = "0"
    #print(pos)
    win.geometry("175x500+"+pos+"+0")


pmenu = tkinter.Menu(win, tearoff=0)

pmenu.add_command(label="Move -->", command=changePosRight)
pmenu.add_command(label="Move <--", command=changePosLeft)
pmenu.add_command(label="Exit", command=win.quit)

win.bind("<Button-3>", showMenu)

########################################################

def read_every_second():
    global x
    cpu_value=psutil.cpu_percent()
    p1.set_value(int(cpu_value))
    
    mem_value=(psutil.virtual_memory())[2]
    p2.set_value(int(mem_value))

    load_value=([x / psutil.cpu_count() * 100 for x in psutil.getloadavg()])[0]
    print([x / psutil.cpu_count() * 100 for x in psutil.getloadavg()])
    p3.set_value(int(load_value))
        
    x+=1    
    if x>100:
#        graph1.draw_axes()
        x=0
    win.after(1000, read_every_second)

p1 = gaugelib.DrawGauge2(
    win,
    max_value=100.0,
    min_value=00.0,
    size=g_size,
    bg_col=g_color,
    unit = "CPU %",bg_sel = 2)
p1.pack()

p2 = gaugelib.DrawGauge2(
    win,
    max_value=100.0,
    min_value= 0.0,
    size=g_size,
    bg_col=g_color,
    unit = "RAM%",bg_sel = 2)
p2.pack()

p3 = gaugelib.DrawGauge2(
    win,
    max_value=500.00,
    min_value= 0.00,
    size=g_size,
    bg_col=g_color,
    unit = "Load Ave",bg_sel = 2)
p3.pack()



read_every_second()
win.wait_visibility(win)
win.wm_attributes('-alpha',tr)   # sets transparency
win.wm_attributes("-topmost", tm) # sets top most window
mainloop()
