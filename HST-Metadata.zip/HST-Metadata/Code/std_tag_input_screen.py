import tkinter as tk
import os

def submit():
    print((site.get()), (city.get()), (state.get()), (country.get()), (photographer.get()),(ptitle.get()),(writer.get()),(src.get()),(rights.get()))
    location.destroy()

    filename = "2010-412.tif"

    os.system("exiftool -Sub-location="+(site.get())+" " + filename)
    os.system("exiftool -City="+(city.get())+" " + filename)
    os.system("exiftool -Province-State="+(state.get())+" " + filename)
    os.system("exiftool -Country-PrimaryLocationName="+(country.get())+" " + filename)
    os.system("exiftool -By-line="+(photographer.get())+" " + filename)
    os.system("exiftool -By-lineTitle"+(ptitle.get())+" " + filename)
    os.system("exiftool -Writer-Editor="+(writer.get())+" " + filename)
    os.system("exiftool -Source="+(src.get())+" " + filename)
    os.system("exiftool -CopyrightNotice="+(rights.get())+" " + filename)

    #os.system("exiftool -City="+(city.get())+" "+"-Sub-location="(site.get())+" " + filename)

    return  
   
location = tk.Tk()  
location.geometry('400x400+100+200')  
  
location.title('Location Information')  

   
site = tk.StringVar()  
city = tk.StringVar() 
state = tk.StringVar() 
country = tk.StringVar()
photographer = tk.StringVar()
ptitle = tk.StringVar()
writer = tk.StringVar()
src = tk.StringVar()
rights = tk.StringVar()  

tk.Label(location, text="Location Information   ").grid(row=1, column=0)  
  
tk.Label(location, text="Site   ").grid(row=2, column=0)  
  
tk.Label(location, text="City   ").grid(row=3, column=0) 

tk.Label(location, text="State  ").grid(row=4, column=0)  

tk.Label(location, text="Country").grid(row=5, column=0)

tk.Label(location, text="Photographer").grid(row=6, column=0)

tk.Label(location, text="Photographer Affiliation").grid(row=7, column=0)

tk.Label(location, text="Writer Editor").grid(row=8, column=0)

tk.Label(location, text="Collection").grid(row=9, column=0)

tk.Label(location, text="Rights").grid(row=10, column=0)

 
  
labelResult = tk.Label(location)  
  
labelResult.grid(row=7, column=2)  
  
e1 = tk.Entry(location, textvariable=site)
e1.grid(row=2, column=2)
e1.insert(10, "'Harry S. Truman Library'")
  
e2 = tk.Entry(location, textvariable=city)
e2.grid(row=3, column=2)
e2.insert(10, "'Independence'")

e3 = tk.Entry(location, textvariable=state)
e3.grid(row=4, column=2)
e3.insert(10, "'MO'")

e4 = tk.Entry(location, textvariable=country)
e4.grid(row=5, column=2)
e4.insert(10, "'USA'")

e5 = tk.Entry(location, textvariable=photographer)
e5.grid(row=6, column=2)
e5.insert(10, "'Unknown'")

e6 = tk.Entry(location, textvariable=ptitle)
e6.grid(row=7, column=2)
e6.insert(10, "'NARA'")

e7 = tk.Entry(location, textvariable=writer)
e7.grid(row=8, column=2)
e7.insert(10, "'J. U'Ren'")

e8 = tk.Entry(location, textvariable=src)
e8.grid(row=9, column=2)
e8.insert(10, "'RG-64'")

e9 = tk.Entry(location, textvariable=rights)
e9.grid(row=10, column=2)
e9.insert(10, "'Public Domain - This item is in the public domain and can be used freely without further permission.'")
  
buttonCal = tk.Button(location, text="Write tags to photos", command=submit).grid(row=11, column=0)


  
location.mainloop()  
