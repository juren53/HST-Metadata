# !/usr/bin/python3
# walk-dir.py
# Tue 19 Nov 2019 12:17:02 PM CST 

from tkinter import filedialog
from tkinter import *

import os

root = Tk()
root.withdraw()
folder_selected = filedialog.askdirectory()
print(folder_selected)

os.chdir(folder_selected)
os.system("ls *.tif")

os.system("ls *.tif > dir.tmp")

lines = []
with open('dir.tmp', 'r') as f:
    for line in f.readlines():
        print(line)
        fn=(line)
        os.system("exiftool -ObjectName -Headline " + fn)
        print(fn[:-5])
