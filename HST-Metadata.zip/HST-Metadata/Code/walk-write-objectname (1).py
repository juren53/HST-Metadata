# !/usr/bin/python3
# walk-write-objectname.py
# Tue 19 Nov 2019 12:18:51 PM CST 

from tkinter import filedialog
from tkinter import *

import os

root = Tk()
root.withdraw()
folder_selected = filedialog.askdirectory()
print(folder_selected)

os.chdir(folder_selected)
os.system("ls *.tif")

os.system("ls *.tif > dir.tmp")

lines = []
with open('dir.tmp', 'r') as f:
    for line in f.readlines():
        print(line)
        fn=(line)
        os.system("exiftool -ObjectName=" + (fn[:-5]) + " " + fn)
        print(fn[:-5])
